//
//  BasicExampleViewController.h
//  FSPagerViewExample-Objc
//
//  Created by Wenchao Ding on 19/01/2017.
//  Copyright © 2017 Wenchao Ding. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BasicExampleViewController : UIViewController


@end

