//
//  FSPagerView.h
//  FSPagerView
//
//  Created by Wenchao Ding on 22/02/2017.
//  Copyright © 2017 Wenchao Ding. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for FSPagerView.
FOUNDATION_EXPORT double FSPagerViewVersionNumber;

//! Project version string for FSPagerView.
FOUNDATION_EXPORT const unsigned char FSPagerViewVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FSPagerView/PublicHeader.h>


