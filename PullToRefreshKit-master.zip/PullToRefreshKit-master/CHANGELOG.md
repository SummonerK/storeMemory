## v0.8.2

### Add

- Add `heightForHeader` and `heightForFooter` in Protocols
- Do not need to set frame height when set up header&footer&left&right

### Updated

- Rename `didBeginEndRefershingAnimation` to `didBeginHideRefershingAnimation`
- Rename `didCompleteEndRefershingAnimation` to `didCompleteHideRefershingAnimation`
- Rename `durationWhenEndRefreshing` to `durationOfHideAnimation`

## Fixd

- Fix footer frame issue
