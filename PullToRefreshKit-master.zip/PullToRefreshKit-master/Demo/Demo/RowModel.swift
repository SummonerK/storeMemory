//
//  RowModel.swift
//  PullToRefreshKit
//
//  Created by huangwenchen on 16/7/13.
//  Copyright © 2016年 Leo. All rights reserved.
//

import Foundation

func random100()->Int{
    return Int(arc4random()%100)
}