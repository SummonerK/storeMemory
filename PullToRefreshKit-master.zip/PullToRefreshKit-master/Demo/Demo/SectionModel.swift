//
//  SectionModel.swift
//  PullToRefreshKit
//
//  Created by huangwenchen on 16/7/13.
//  Copyright © 2016年 Leo. All rights reserved.
//

import Foundation

struct SectionModel {
    var rowsCount:Int
    var sectionTitle:String
    var rowsTitles:[String]
    var rowsTargetControlerNames:[String]
}
